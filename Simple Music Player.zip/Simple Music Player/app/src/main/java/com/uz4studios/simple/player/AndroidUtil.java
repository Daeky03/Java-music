package com.uz4studios.simple.player;
import android.content.Context;
import android.widget.Toast;

public class AndroidUtil {
    
    public static void showMessage(Context context,String str){
        Toast.makeText(context,str,Toast.LENGTH_SHORT).show();
    }
    
    
    
}
