package com.uz4studios.simple.player;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;


public class MainActivity extends  Activity { 

    private Timer _timer = new Timer();

    private String song_duration = "";
    private double song = 0;
    private String filepath = "";
    private boolean onSeek = false;
    private double a = 0;
    private String ed = "";
    private double n = 0;
    private HashMap<String, Object> map_test = new HashMap<>();
    private String list_json = "";
    private String item_json = "";

    private ArrayList<HashMap<String, Object>> All_Song_Data = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> ImageMap = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> background_list = new ArrayList<>();

    private ListView listview1;
    private LinearLayout linear4;
    private LinearLayout linear3;
    private LinearLayout linear2;
    private TextView textview1;
    private TextView time_current;
    private SeekBar seekbar1;
    private TextView time_duration;
    private ImageView imageview1;
    private ImageView imageview2;
    private ImageView imageview3;

    private AlertDialog.Builder permission;
    private TimerTask timer;
    private MediaPlayer mp;
    private Calendar calendar = Calendar.getInstance();
    private AlertDialog.Builder media_error_dialog;
    private Intent i = new Intent();
    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize(_savedInstanceState);
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
                || checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
            }
            else {
                initializeLogic();
            }
        }
        else {
            initializeLogic();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1000) {
            initializeLogic();
        }
    }

    private void initialize(Bundle _savedInstanceState) {

        listview1 = (ListView) findViewById(R.id.listview1);
        
        
        
        time_current = (TextView) findViewById(R.id.time_current);
        seekbar1 = (SeekBar) findViewById(R.id.seekbar1);
        textview1=findViewById(R.id.textview1);
        time_duration = (TextView) findViewById(R.id.time_duration);
        imageview1 = (ImageView) findViewById(R.id.imageview1);
        imageview2 = (ImageView) findViewById(R.id.imageview2);
        imageview3 = (ImageView) findViewById(R.id.imageview3);
        permission = new AlertDialog.Builder(this);
        media_error_dialog = new AlertDialog.Builder(this);
       

        listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
                    final int _position = _param3;
                    song = _position;
                    ((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
                    if(mp == null){
                        mp=new MediaPlayer();
                    }else{
                        mp.pause();
                        mp.reset();
                    }
                    filepath = All_Song_Data.get((int)_position).get("data").toString();
                    try {
                        if (mp.isPlaying()) {
                            mp.reset();
                            //mp.prepare();
                            mp.prepareAsync();
                        }else{
                            mp.setDataSource(filepath);
                            mp.prepare();
                            mp.start();
                            _mp_move();
                        }
                    } catch (java.io.IOException e) { }
                    imageview2.setImageResource(R.drawable.ic_pause);
                }
            });

        seekbar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged (SeekBar _param1, int _param2, boolean _param3) {
                    final int _progressValue = _param2;
                    if (mp != null){
                        if (onSeek) {
                            if (mp.isPlaying()) {
                                mp.pause();
                                mp.seekTo((int)(_progressValue));
                                imageview2.setImageResource(R.drawable.ic_pause);
                            }
                            else {
                                mp.pause();
                                mp.seekTo((int)(_progressValue));
                                imageview2.setImageResource(R.drawable.ic_pause);
                            }
                        }
                    }
                }

                @Override
                public void onStartTrackingTouch(SeekBar _param1) {
                    if (mp != null){
                        onSeek = true;
                    }
                }

                @Override
                public void onStopTrackingTouch(SeekBar _param2) {
                    if (mp != null){
                        onSeek = false;
                        if (mp.isPlaying()) {

                        }
                        else {
                            mp.start();
                        }
                    }
                }
            });

        imageview1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View _view) {
                    if(mp == null){
                        mp=new MediaPlayer();
                    }else{
                        mp.pause();
                        mp.reset();
                        if (All_Song_Data.size() == 0) {
                            AndroidUtil.showMessage(getApplicationContext(), "List lenght from 0");
                        }
                        else {
                            song--;
                            if (song > -1) {
                                filepath = All_Song_Data.get((int)song).get("data").toString();
                                try {
                                    if (mp.isPlaying()) {
                                        mp.reset();
                                        mp.prepare();
                                    }else{
                                        mp.setDataSource(filepath);
                                        mp.prepare();
                                        mp.start();
                                    }
                                } catch (Exception e) {
                                }
                                ((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
                                _mp_move();
                            }
                            else {
                                song = 0;
                                AndroidUtil.showMessage(getApplicationContext(), "Top of list");
                            }
                        }
                    }
                }
            });

        imageview2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View _view) {
                    if(mp != null){
                        if (mp.isPlaying()) {
                            mp.pause();
                            imageview2.setImageResource(R.drawable.ic_play);
                        }
                        else {
                            mp.start();
                            imageview2.setImageResource(R.drawable.ic_pause);
                        }
                    }
                }
            });

        imageview3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View _view) {
                    if(mp == null){
                        mp=new MediaPlayer();
                    }else{
                        mp.pause();
                        mp.reset();
                        if (All_Song_Data.size() == 0) {
                            AndroidUtil.showMessage(getApplicationContext(), "List lenght from 0");
                        }
                        else {
                            song++;
                            if (song < All_Song_Data.size()) {
                                filepath = All_Song_Data.get((int)song).get("data").toString();
                                try {
                                    if (mp.isPlaying()) {
                                        mp.reset();
                                        mp.prepare();
                                    }else{
                                        mp.setDataSource(filepath);
                                        mp.prepare();
                                        mp.start();
                                    }
                                } catch (Exception e) {
                                }
                                ((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
                                _mp_move();
                            }
                            else {
                                song = All_Song_Data.size();
                                AndroidUtil.showMessage(getApplicationContext(), "end of list");
                            }
                        }
                    }
                }
            });

        
    }

    private void initializeLogic() {
        getWindow().getDecorView()
            .setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );
        
         FileUtil.writeFile(FileUtil.getExternalStorageDir(), FileUtil.getExternalStorageDir());
        
        listview1.setAdapter(new Listview1Adapter(All_Song_Data));
        ((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
        _CheckSelf();
    }

    @Override
    protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {

        super.onActivityResult(_requestCode, _resultCode, _data);

        switch (_requestCode) {

            default:
                break;
        }
    }

    @Override
    public void onStart() {
        super.onStart();

    }
    public void _CheckSelf () {
        if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_DENIED) {
            permission.setTitle("Note Permissions");
            permission.setMessage("Read permission required, do you allow it?");
            permission.setPositiveButton("Yeah", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface _dialog, int _which) {
                        requestPermissions(new String[] {android.Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
                    }
                });
            permission.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface _dialog, int _which) {
                        AndroidUtil.showMessage(getApplicationContext(), "Obs files could not be retrieved not allowed");
                    }
                });
            permission.setCancelable(false);
            permission.create().show();
        }else {
            getAllSongData();
        }
    }


    public void _AllData () {
    }
    public void getAllSongData() { 

        String[] projection = {

            android.provider.MediaStore.Audio.Media._ID, 
            android.provider.MediaStore.Audio.Media.ALBUM,
            android.provider.MediaStore.Audio.Media.ALBUM_KEY, 
            android.provider.MediaStore.Audio.Media.ARTIST,
            android.provider.MediaStore.Audio.Media.DATA,
            android.provider.MediaStore.Audio.Media.TITLE,
            android.provider.MediaStore.Audio.Media.DURATION,

            android.provider.MediaStore.Audio.Media.ALBUM_ID,
            /*
             android.provider.MediaStore.Audio.Albums.ALBUM_ART;
             */
        };

        String orderBy = " " + android.provider.MediaStore.MediaColumns.DISPLAY_NAME;

        android.net.Uri uri = android.provider.MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI; 

        cursor = getApplicationContext().getContentResolver().query(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, null, null, orderBy);
        getAlbumColumnData(cursor);
    } 
    {
    }
    public static android.database.Cursor cursor;
    public static int music_column_index;

    private void getAlbumColumnData(android.database.Cursor cur) {
        try {
            if (cur.moveToFirst()) {
                String id;
                String name;
                String data;
                String artist;
                String album;
                String songs_duration;

                do {

                    id = cur.getString(cur.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.ALBUM_ID));

                    name = cur.getString(cur.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.TITLE));
                    data = cur.getString(cur.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA));

                    artist = cur.getString(cur.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.ARTIST));

                    album = cur.getString(cur.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.ALBUM));

                    {
                        HashMap<String, Object> _item = new HashMap<>();
                        _item.put("album", album);
                        _item.put("name", name);
                        _item.put("data", data);
                        _item.put("artist", artist);
                        _item.put ("id",id);
                        All_Song_Data.add( _item);
                    }
                } while (cur.moveToNext());}
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    {
    }
    private String setCorrectDuration(String songs_duration) {
        // TODO Auto-generated method stub

        if(Integer.valueOf(songs_duration) != null) {
            int time = Integer.valueOf(songs_duration);

            int seconds = time/1000;
            int minutes = seconds/60;
            seconds = seconds % 60;

            if(seconds<10) {
                songs_duration = String.valueOf(minutes) + ":0" + String.valueOf(seconds);
                song_duration = songs_duration;
            } else {
                songs_duration = String.valueOf(minutes) + ":" + String.valueOf(seconds);
                song_duration = songs_duration;
            }
            return songs_duration;
        }
        return null;
    }

    {
    }


    public void _mp_move () {
        System.runFinalization();
        Runtime.getRuntime().gc();
        System.gc();
        if (mp != null){
            textview1.setText(All_Song_Data.get((int)song).get("artist").toString().concat(" - ".concat(All_Song_Data.get((int)song).get("name").toString())));
            calendar.setTimeInMillis((long)(mp.getDuration()));
            time_duration.setText(new SimpleDateFormat("mm:ss").format(calendar.getTime()));
            seekbar1.setMax((int)mp.getDuration());
            timer = new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                calendar.setTimeInMillis((long)(mp.getCurrentPosition()));
                                time_current.setText(new SimpleDateFormat("mm:ss").format(calendar.getTime()));
                                seekbar1.setProgress((int)mp.getCurrentPosition());
                            }
                        });
                }
            };
            _timer.scheduleAtFixedRate(timer, (int)(400), (int)(400));
        }else {
            AndroidUtil.showMessage(getApplicationContext(), "Not: Media is not found expention");
        }
        mp.setOnCompletionListener (new MediaPlayer.OnCompletionListener (
            ) {
                public void
                onCompletion (MediaPlayer theMediaPlayer) {
                    if(mp == null){
                        mp=new MediaPlayer();
                    }else{
                        mp.pause();
                        mp.reset();
                        if (!(All_Song_Data.size() == 0)) {
                            song++;
                            if (song < All_Song_Data.size()) {
                                filepath = All_Song_Data.get((int)song).get("data").toString();
                                try {
                                    if (mp.isPlaying()) {
                                        mp.reset();
                                        mp.prepare();
                                    }else{
                                        mp.setDataSource(filepath);
                                        mp.prepare();
                                        mp.start();
                                    }
                                } catch (Exception e) {
                                }
                                ((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
                                _mp_move();
                            }
                            else {
                                song = All_Song_Data.size();
                            }
                        }
                    }
                }});
        mp.setOnErrorListener(new MediaPlayer.OnErrorListener(){

                @Override
                public boolean onError(MediaPlayer p1, int p2, int p3)
                {
                    if (!(All_Song_Data.size() == 0)) {
                        if (!((song == All_Song_Data.size()) || (song == 0))) {
                            media_error_dialog.setTitle("Media Error");
                            media_error_dialog.setMessage("Unfortunately this file is corrupt, media cannot be played");
                            media_error_dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface _dialog, int _which) {

                                    }
                                });
                            media_error_dialog.create().show();
                        }
                        else {

                        }
                    }
                    mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener(){
                            @Override
                            public void onPrepared(MediaPlayer mp){
                            }
                        });
                    return true;
                }
            });
    }


    public class Listview1Adapter extends BaseAdapter {
        ArrayList<HashMap<String, Object>> _data;
        public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
            _data = _arr;
        }

        @Override
        public int getCount() {
            return _data.size();
        }

        @Override
        public HashMap<String, Object> getItem(int _index) {
            return _data.get(_index);
        }

        @Override
        public long getItemId(int _index) {
            return _index;
        }
        @Override
        public View getView(final int _position, View _v, ViewGroup _container) {
            LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View _view = _v;
            if (_view == null) {
                _view = _inflater.inflate(R.layout.custom, null);
            }

            final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
            final ImageView imageview1 = (ImageView) _view.findViewById(R.id.imageview1);
            final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
            final TextView song_name = (TextView) _view.findViewById(R.id.song_name);
            final TextView song_artist = (TextView) _view.findViewById(R.id.song_artist);

            if (_data.size() > 0) {
                if (_data.get((int)_position).containsKey("name")) {
                    song_name.setText(_data.get((int)_position).get("name").toString());
                }
                if (_data.get((int)_position).containsKey("artist")) {
                    song_artist.setText(_data.get((int)_position).get("artist").toString());
                }
                if (song == _position) {
                    song_name.setTextColor(0xFF000000);
                }
                else {
                    song_name.setTextColor(0xFF9E9E9E);
                }
            }

            return _view;
        }
    }}


